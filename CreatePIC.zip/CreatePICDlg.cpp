
// CreatePICDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CreatePIC.h"
#include "CreatePICDlg.h"
#include "DragDropEdit.h"
#include <afxtempl.h>  
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CCreatePICDlg dialog



CCreatePICDlg::CCreatePICDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_CREATEPIC_DIALOG, pParent)
	, m_edFileName(10)
	, m_FolderName(_T("c:\\"))
	, m_FileExt(_T("mp3"))
	, m_fileSize(5)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_fileFolderName = _T("");
}

void CCreatePICDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_edFileName);

	DDX_Text(pDX, IDC_FolderName, m_FolderName);
	DDX_Text(pDX, IDC_FileExt, m_FileExt);
	DDX_Text(pDX, IDC_FileSize, m_fileSize);
}

BEGIN_MESSAGE_MAP(CCreatePICDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, &CCreatePICDlg::OnBnClickedOk)
	ON_WM_DROPFILES()
	ON_BN_CLICKED(IDC_BUTTON1, &CCreatePICDlg::OnClickedCreatePic)
	ON_BN_CLICKED(IDC_BUTTON2, &CCreatePICDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CCreatePICDlg::OnBnClickedButton3)
//	ON_EN_UPDATE(IDC_FolderName, &CCreatePICDlg::OnUpdateFoldername)
END_MESSAGE_MAP()


// CCreatePICDlg message handlers

BOOL CCreatePICDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	m_dropEdit.SubclassDlgItem(IDC_FolderName, this);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCreatePICDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCreatePICDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CCreatePICDlg::OnBnClickedOk()
{

	/*CString dirName("C:\\TMP\\*.bmp");
	bool temp = this->fileArray(dirName);
	
	for (int nCnt = 0; nCnt < this->m_files.GetSize(); nCnt++)
	{
		CString temp = this->m_files[nCnt];
	}
	for (int i = 0; i < 10; i++)
	{
		CreateBMPFiles(1);
		Sleep(1000);
	}*/
	// TODO: Add your control notification handler code here
	CDialogEx::OnOK();
}


// // to create a file based no the number of input
bool CCreatePICDlg::CreateBMPFiles(int fileNumbers)
{
	UpdateData(TRUE);
	if (fileNumbers < 0) return false;
	CString szToWriteOnPic = _T("TEST Sample");
	BITMAPINFO bi;
	ZeroMemory(&bi, sizeof(BITMAPINFO));
	bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bi.bmiHeader.biWidth = 1024;
	bi.bmiHeader.biHeight = 512;
	bi.bmiHeader.biPlanes = 1;
	bi.bmiHeader.biBitCount = 24;
	int nWidth = 1024;//GetSystemMetrics(SM_CXSCREEN);
	int nHeight = 512;// GetSystemMetrics(SM_CYSCREEN);
	

	srand(time(NULL));
	for (int i = 0; i<fileNumbers; i++)
	{
		CString stStamp = CTime::GetCurrentTime().Format("%d%b%y_%H_%M_%S");
		HDC hScrDC = ::GetDC(NULL);
		HDC hMemDC = NULL;
		BYTE *lpBitmapBits = NULL;

		RECT pos = { 0,0,1024,512 };
		hMemDC = ::CreateCompatibleDC(hScrDC);
	
		HBITMAP bitmap = CreateDIBSection(hMemDC, &bi, DIB_RGB_COLORS, (LPVOID*)&lpBitmapBits, NULL, 0);
		HGDIOBJ oldbmp = SelectObject(hMemDC, bitmap);

		CDC tmpDrawingdc;
		tmpDrawingdc.Attach(hMemDC);
		tmpDrawingdc.SelectObject(GetStockObject(DEFAULT_GUI_FONT));
		// set back ground color
	
		HBRUSH hBgBrush = ::CreateSolidBrush(RGB((rand()%255), (rand() % 255), (rand() % 255)));
		::FillRect(tmpDrawingdc, &pos, hBgBrush);
		::DeleteObject(hBgBrush);
		//Set text color
		tmpDrawingdc.SetTextColor(RGB(0, 0, 255));
		//draw the text
		LOGFONT lf;
		CFont m_font;// Used to create the CFont.
		memset(&lf, 0, sizeof(LOGFONT));   // Clear out structure.
		lf.lfHeight = 200;	// Request a 20-pixel-high font

		lstrcpy(lf.lfFaceName, _T("Times New Roman"));
		m_font.CreateFontIndirect(&lf);    // Create the font.
		CFont *pold_font = tmpDrawingdc.SelectObject(&m_font);
		RECT posDraw = { 10,10,1000,200 };
		tmpDrawingdc.SetBkMode(TRANSPARENT);
		tmpDrawingdc.SetBkColor(RGB(0, 0, 255));
		tmpDrawingdc.DrawText(szToWriteOnPic, szToWriteOnPic.GetLength(), &posDraw, DT_CALCRECT);
		tmpDrawingdc.DrawText(szToWriteOnPic, szToWriteOnPic.GetLength(), &posDraw, 0);
		tmpDrawingdc.SelectObject(pold_font);
		::DeleteObject(m_font);

		BITMAPFILEHEADER bh;
		ZeroMemory(&bh, sizeof(BITMAPFILEHEADER));
		bh.bfType = 0x4d42; //bitmap 
		bh.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
		bh.bfSize = bh.bfOffBits + ((nWidth*nHeight) * 3);

		CFile file;
		// CString stemp = _T("C:\\TMP\\")+ stStamp +_T(".bmp");
		CString stemp = this->m_FolderName  +_T("\\") + stStamp + _T(".bmp");
		//LPCTSTR
		if (file.Open(stemp, CFile::modeCreate | CFile::modeWrite))
		{
			file.Write(&bh, sizeof(BITMAPFILEHEADER));
			file.Write(&(bi.bmiHeader), sizeof(BITMAPINFOHEADER));
			file.Write(lpBitmapBits, 3 * nWidth * nHeight);
			file.Close();
		}

		//SelectObject(hMemDC, oldbmp);
		DeleteObject(bitmap);
		DeleteObject(hMemDC);
		::ReleaseDC(NULL, hScrDC);
		Sleep(1000);
	}
	return TRUE;
}


bool CCreatePICDlg::fileArray(CString folderName)
{   
	HANDLE hFind;
	WIN32_FIND_DATA data;
	this->m_files.RemoveAll();
	hFind = FindFirstFile(folderName, &data);
	if (hFind != INVALID_HANDLE_VALUE) {
		do {
			this->m_files.Add(data.cFileName);
		} while (FindNextFile(hFind, &data));
		FindClose(hFind);
	}
	else {
		return false;
	}
	return true;
}


void CCreatePICDlg::OnDropFiles(HDROP hDropInfo)
{
	// TODO: Add your message handler code here and/or call default
	WORD wNumFilesDropped = DragQueryFile(hDropInfo, -1, NULL, 0);

	CString csFirstFile = _T("");

	// there may be many, but we'll only use the first   
	if (wNumFilesDropped > 0)
	{
		// Get the number of bytes required by the file's full pathname   
		WORD wPathnameSize = DragQueryFile(hDropInfo, 0, NULL, 0);

		// Allocate memory to contain full pathname & zero byte   
		wPathnameSize += 1;

		TCHAR * pFile = new TCHAR[wPathnameSize];
		if (pFile == NULL)
		{
			ASSERT(0);
			DragFinish(hDropInfo);
			return;
		}

		// Copy the pathname into the buffer   
		DragQueryFile(hDropInfo, 0, pFile, wPathnameSize);

		csFirstFile = pFile;
		CEdit* pEd = (CEdit*)GetDlgItem(IDC_FolderName);
		pEd->SetWindowTextW(csFirstFile);
		this->m_fileFolderName = csFirstFile;

		// clean up   
		delete[] pFile;
	}

	// Free the memory block containing the dropped-file information   
	DragFinish(hDropInfo);

	//// if this was a shortcut, we need to expand it to the target path   
	//CString csExpandedFile = ExpandShortcut(csFirstFile);

	//// if that worked, we should have a real file name   
	//if (!csExpandedFile.IsEmpty())
	//{
	//	csFirstFile = csExpandedFile;
	//}


	if (!csFirstFile.IsEmpty())
	{
	
		//
	}

	CDialogEx::OnDropFiles(hDropInfo);
}


void CCreatePICDlg::OnClickedCreatePic()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	int fileNumber = this->m_edFileName;
	CPoint rc(0, 0);
	CreateBMPFiles(fileNumber);
	AfxMessageBox(_T("Done"));
	// TODO: Add your control notification handler code here
	//CDialogEx::OnOK();

}


// to load a file into cbitmap and draw a line rando
bool CCreatePICDlg::LoadBMPModify(CString fileName, CPoint randomRect, COLORREF colorLine)
{
	//fileName = _T("c:\\TMP\\t.bmp");
	CImage tmpimg;
	tmpimg.Load(fileName);
	HDC imgHDC = tmpimg.GetDC();
	CDC* pDC = CDC::FromHandle(imgHDC);
	CPen tmpPen, *oldPen;
	tmpPen.CreatePen(PS_SOLID, 10, colorLine);
	oldPen = pDC->SelectObject(&tmpPen);
	pDC->MoveTo(10, 10);
	pDC->LineTo(randomRect.x, randomRect.y);
	BitBlt(imgHDC, 0, 0, tmpimg.GetWidth(), tmpimg.GetHeight(), pDC->GetSafeHdc(), 0, 0, SRCCOPY);

	pDC->SelectObject(oldPen);
	tmpimg.Save(fileName);
	tmpimg.ReleaseDC();
	// Use pDC here
	return false;
}


void CCreatePICDlg::OnBnClickedButton2()
{
	UpdateData(TRUE);
	CString stemp = this->m_FolderName + _T("\\*.bmp");
	bool temp = this->fileArray(stemp);
	srand(time(NULL));
	CPoint Pt;

	for (int nCnt = 0; nCnt < this->m_files.GetSize(); nCnt++)
	{
		Pt = { (rand() % 1000),(rand() % 500)};
		CString temp = this->m_FolderName+_T("\\")+this->m_files[nCnt];
		LoadBMPModify(temp, Pt, RGB(255, 0, 0));

	}
	AfxMessageBox(_T("Done"));
	// TODO: Add your control notification handler code here
}


// create a fake file for given extension
bool CCreatePICDlg::CreateFixedFile(CString fileName, unsigned int fileSize, CString fileExtension)
{
	/*fileName = _T("C:\\Users\\bailin.li\\Desktop\\test\\test1.txt");
	fileExtension = _T(".mp2");
	fileSize = 10;*/
	ULONGLONG dwSizeFile= 1024 * 1024 * fileSize;
	ULONGLONG endp;
	CTime today(CTime::GetCurrentTime());   // Initialize CTime with current time
	try
	{
		// try to open the file
		CStdioFile tmpFile(fileName+_T(".")+fileExtension, CFile::modeCreate|CFile::modeReadWrite|CFile::typeText);
		tmpFile.SetLength(dwSizeFile);
		tmpFile.SeekToEnd();
		endp = tmpFile.GetPosition();
		tmpFile.SeekToBegin();
		while (tmpFile.GetPosition() <= endp)
		{
			CString stime;
			stime.Format(_T(" test data sample day= %02d Month= %02d year= %04d %2d:%02d:%02d,%d \r\n"), today.GetDay(), today.GetMonth(), today.GetYear(), today.GetHour(), today.GetMinute(), today.GetSecond(), tmpFile.GetPosition());
			tmpFile.WriteString(stime);
		}
		tmpFile.Flush();
		// close the file handle
		tmpFile.Close();
	}
	catch (CFileException* pEx)
	{
		// if an error occurs, just make a message box
		pEx->ReportError();
		pEx->Delete();
	}
	//AfxMessageBox(_T("Done"));
	return false;
}


void CCreatePICDlg::OnBnClickedButton3()
{
	UpdateData(TRUE);
	int files = this->m_edFileName;
	for(int i=0;i< this->m_edFileName;i++)
	{   
		CString stStamp = CTime::GetCurrentTime().Format("%d%b%y_%H_%M_%S");
		stStamp.AppendFormat(_T("_%2d"), i);
		CString stemp = this->m_FolderName + _T("\\")+stStamp;
		
		CreateFixedFile(stemp, this->m_fileSize, this->m_FileExt);
	}
	AfxMessageBox(_T("Done"));
	// TODO: Add your control notification handler code here
}

