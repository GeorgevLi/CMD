// DragDropEdit.cpp : implementation file
//

#include "stdafx.h"
#include "CreatePIC.h"
#include "DragDropEdit.h"


// DragDropEdit

IMPLEMENT_DYNAMIC(DragDropEdit, CEdit)

DragDropEdit::DragDropEdit()
{

}

DragDropEdit::~DragDropEdit()
{
}


BEGIN_MESSAGE_MAP(DragDropEdit, CEdit)
	ON_WM_DROPFILES()
END_MESSAGE_MAP()

// DragDropEdit message handlers

void DragDropEdit::OnDropFiles(HDROP hDropInfo)
{
	// TODO: Add your message handler code here and/or call default
	// TODO: Add your message handler code here and/or call default
	WORD wNumFilesDropped = DragQueryFile(hDropInfo, -1, NULL, 0);
	CString csFirstFile = _T("");
	// there may be many, but we'll only use the first   
	if (wNumFilesDropped > 0)
	{
		// Get the number of bytes required by the file's full pathname   
		WORD wPathnameSize = DragQueryFile(hDropInfo, 0, NULL, 0);
		// Allocate memory to contain full pathname & zero byte   
		wPathnameSize += 1;
		TCHAR * pFile = new TCHAR[wPathnameSize];
		if (pFile == NULL)
		{
			ASSERT(0);
			DragFinish(hDropInfo);
			return;
		}

		// Copy the pathname into the buffer   
		DragQueryFile(hDropInfo, 0, pFile, wPathnameSize);

		csFirstFile = pFile;
		//CEdit* pEd = (CEdit*)GetDlgItem(IDC_FolderName);
		SetWindowTextW(csFirstFile);
		// clean up   
		delete[] pFile;
	}
	// Free the memory block containing the dropped-file information   
	DragFinish(hDropInfo);

	//// if this was a shortcut, we need to expand it to the target path   
	//CString csExpandedFile = ExpandShortcut(csFirstFile);

	//// if that worked, we should have a real file name   
	//if (!csExpandedFile.IsEmpty())
	//{
	//	csFirstFile = csExpandedFile;
	//}

	// TODO:  Add your control notification handler code here
	CEdit::OnDropFiles(hDropInfo);
}
