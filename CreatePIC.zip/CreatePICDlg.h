
// CreatePICDlg.h : header file
//
#include "DragDropEdit.h"

#pragma once


// CCreatePICDlg dialog
class CCreatePICDlg : public CDialogEx
{
// Construction
public:
	CCreatePICDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CREATEPIC_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	// // to create a file based no the number of input
	bool CreateBMPFiles(int fileNumbers);
	bool fileArray(CString folderName);
	CArray<CString, CString> m_files;
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnClickedCreatePic();
	CString m_fileFolderName;
	// how many file to create
	int m_edFileName;
	// to load a file into cbitmap and draw a line rando
	bool LoadBMPModify(CString fileName, CPoint randomRect, COLORREF colorLine);
	afx_msg void OnBnClickedButton2();
	CString m_FolderName;
	// create a fake file for given extension
	bool CreateFixedFile(CString fileName, unsigned int fileSize, CString fileExtension);
	afx_msg void OnBnClickedButton3();
	// file extions
	CString m_FileExt;
	// file size in term of M
	UINT m_fileSize;
	DragDropEdit m_dropEdit;
//	afx_msg void OnUpdateFoldername();
};
