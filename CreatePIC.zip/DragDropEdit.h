#pragma once


// DragDropEdit

class DragDropEdit : public CEdit
{
	DECLARE_DYNAMIC(DragDropEdit)

public:
	DragDropEdit();
	virtual ~DragDropEdit();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnDropFiles(HDROP hDropInfo);
};


